package com.model;

public class Professeur {

	
	public int id;
	public String nom;
	public String prenom;
	public String typedeprof;
	public String login;
	public String password;
	
	

	
	
	public int getId() {
		
		return id;
	}

}
