package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.ModAcquire;


public class Acquire extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException{
	
		RequestDispatcher dispatch = request.getRequestDispatcher("remote.jsp");
		dispatch.forward(request, response);
	}	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException{
	
		ModAcquire m = (ModAcquire) this.getServletContext().getAttribute("Acquire");
		response.setContentType("text/html");
		m.handleResponde(request);
		System.out.println(m);
		
		
	}	
	
	
	
}
