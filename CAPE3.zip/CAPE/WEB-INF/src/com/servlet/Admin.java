package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Bd;
import com.model.Cours;
import com.model.Exporteur;
import com.model.ModAcquire;
import com.model.Professeur;


public class Admin extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException{
		
		RequestDispatcher dispatch = request.getRequestDispatcher("admin.jsp");
		dispatch.forward(request, response);

	}	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException, ServletException{
	
	ModAcquire m = (ModAcquire) this.getServletContext().getAttribute("Acquire");
	String command = request.getParameter("value");
	
	
	if (command.equals("start"))
		m.start();
	if(command.equals("stop"))
	{
		String id = (String) request.getSession().getAttribute("id_cours");
		int num  = (Integer) request.getSession().getAttribute("num");
		m.stop(num, id );
		request.getSession().setAttribute("num",num+1);
		
		
	}
	if(command.equals("setCours"))
	{
		request.getSession().setAttribute("num",0);
		request.getSession().setAttribute("id_cours", request.getParameter("id").substring(1));
	
		
	}
	if(command.equals("liste"))
	{
		String login = (String) request.getSession().getAttribute("login");
		String password = (String) request.getSession().getAttribute("password");
		PrintWriter out = response.getWriter();
		ArrayList<Cours> liste_cours = Bd.getObject().getCours(login,password);
		out.println("<ul>");
		for (Cours c : liste_cours)
			out.print("<li class='liste' id='c"+c.id+"'>Intitul&eacute : "+c.intitule+
					"<br/> Module : "+c.module+"</li>");
		out.println("</ul>");
	}
	
	
	if(command.equals("get"))
	{
		PrintWriter out = response.getWriter();
		out.print(m.toString());
	}
		
	if(command.equals("has_changed"))
	{
		PrintWriter out = response.getWriter();
		out.print(m.has_changed());
	}
	
	if(command.equals("ajoute_cours"))
	{	
		String intitule = request.getParameter("intitule");
		String module = request.getParameter("module");
		System.out.println("Demande d'ajout de cours " +intitule+","+module);
		String login = (String) request.getSession().getAttribute("login");
		String password = (String) request.getSession().getAttribute("password");
		Professeur p = Bd.getObject().getProf(login, password);
		Cours c = new Cours(p,intitule,module);
		Bd.getObject().addCours(c);
		
		
		
	}
	
	if(command.equals("export"))
	{	
		Exporteur.QuestionsToCsv(Bd.getObject().getQuestions(request.getSession().getAttribute("id_cours").toString()));	
		
	}
	
	
}	
	
	
}
