package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class admin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n");
      out.write("<html>\n");
      out.write("<head>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
      out.write("<title>Insert title here</title>\n");
      out.write("\n");
      out.write("<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js\"></script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("function doSomething() {\n");
      out.write("\t$.post(\"Admin\" , {\"value\" :\"has_changed\"} ,function(data)\n");
      out.write("\t{\n");
      out.write("\t\t\n");
      out.write("\t\t\n");
      out.write("\n");
      out.write("\tif (data==\"true\")\n");
      out.write("\t{\n");
      out.write("\t\trefresh();\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("\t});\n");
      out.write("\t\n");
      out.write("}\n");
      out.write("\n");
      out.write("function refresh()\n");
      out.write("{\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\t$.post(\"Admin\", {\"value\" : \"get\" } , function(data2) {\n");
      out.write("\t//\t$(\"#return\").html(data2);\n");
      out.write("\t\t\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t      var data = new google.visualization.DataTable();\n");
      out.write("\t\t\t      var obj = jQuery.parseJSON(data2);\n");
      out.write("\t\t\t   \t\t$(\"#A\").html(obj.A);\n");
      out.write("\t\t\t   \t\t$(\"#B\").html(obj.B);\n");
      out.write("\t\t\t   \t\t$(\"#C\").html(obj.C);\n");
      out.write("\t\t\t   \t\t$(\"#D\").html(obj.D);\n");
      out.write("\t\t\t   \t\t\n");
      out.write("\t\t\t      data.addColumn('string', 'Answer');\n");
      out.write("\t\t\t      data.addColumn('number', 'Count');\n");
      out.write("\t\t\t      data.addRows([\n");
      out.write("\t\t\t        ['A', obj.A],\n");
      out.write("\t\t\t        ['B', obj.B],\n");
      out.write("\t\t\t        ['C', obj.C], \n");
      out.write("\t\t\t        ['D', obj.D]\n");
      out.write("\t\t\t       \n");
      out.write("\t\t\t      ]);\n");
      out.write("\n");
      out.write("\t\t\t      // Instantiate and draw our chart, passing in some options.\n");
      out.write("\t\t\t      var chart = new google.visualization.PieChart(document.getElementById('chart_div'));\n");
      out.write("\t\t\t      chart.draw(data, {width: 400, height: 240});\n");
      out.write("\t\t\t  \n");
      out.write("\n");
      out.write("\t});\n");
      out.write("\t\n");
      out.write("\t}\n");
      out.write("\n");
      out.write("$(document).ready(function(){\n");
      out.write("\t$(\"#cours_cache\").hide();\n");
      out.write("\t\n");
      out.write("\t$(\"#creer\").click(function(){\n");
      out.write("\t\t$(\"#cours_cache\").fadeIn();\n");
      out.write("\t\t\n");
      out.write("\t});\n");
      out.write("\t\n");
      out.write("\t$(\"#creer_cours\").click(function(){\n");
      out.write("\t\t$(\"#cours_cache\").fadeOut();\n");
      out.write("\t\t$.post(\"Admin\" , {\"value\" :\"ajoute_cours\",\"intitule\":$(\"#intitule\").attr(\"value\"),\"module\":$(\"#module\").attr(\"value\")} ,function(data){});\n");
      out.write("\t\t\n");
      out.write("\t});\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("\trefresh();\n");
      out.write("\t$(\"button\").click(function(){\n");
      out.write("\t\t$.post(\"Admin\",{ \"value\" : $(this).attr(\"id\")});\t\n");
      out.write("\t});\n");
      out.write("\t\t\n");
      out.write("\tsetInterval( \"doSomething()\", 2000 );\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("});\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("\n");
      out.write(" <script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>\n");
      out.write(" <script type=\"text/javascript\">\n");
      out.write("      // Load the Visualization API and the piechart package.\n");
      out.write("      google.load('visualization', '1', {'packages':['corechart']});\n");
      out.write("      // Set a callback to run when the Google Visualization API is loaded.\n");
      out.write("      google.setOnLoadCallback(doSomething);\n");
      out.write("      // Callback that creates and populates a data table, \n");
      out.write("      // instantiates the pie chart, passes in the data and\n");
      out.write("      // draws it.\n");
      out.write("   \n");
      out.write("    </script>\n");
      out.write("    \n");
      out.write(" \n");
      out.write("    \n");
      out.write("    <style>\n");
      out.write("    * {\n");
      out.write("    margin:0;\n");
      out.write("    padding : 0;\n");
      out.write("    font-family:sans-serif;\n");
      out.write("    }\n");
      out.write("    body{background:lightblue;margin:0;padding : 0;}\n");
      out.write("    #content{\n");
      out.write("    position:absolute;\n");
      out.write("    padding-left:5%;\n");
      out.write("    left : 10%;\n");
      out.write("    width : 75%;\n");
      out.write("    height : 100%;\n");
      out.write("    background:white;\n");
      out.write("    margin : auto;\n");
      out.write("    }\n");
      out.write("    #chart_div{\n");
      out.write("    float : right;\n");
      out.write("    }\n");
      out.write("    #return {\n");
      out.write("    float : left; }\n");
      out.write("    h1{\n");
      out.write("    margin :  2% 0 2% 0;\n");
      out.write("    }\n");
      out.write("    thead {\n");
      out.write("    background : lightblue;\n");
      out.write("\n");
      out.write("    }\n");
      out.write("    table{\n");
      out.write("    \t\n");
      out.write("    \tmargin-top : 19%;\n");
      out.write("        border-collapse : collapse;\n");
      out.write("        border : solid 1px black;\n");
      out.write("    }\n");
      out.write("    th{\n");
      out.write("\n");
      out.write("    padding : 1%;\n");
      out.write("    width : 1%;\n");
      out.write("    }\n");
      out.write("    td {\n");
      out.write("    text-align:center;\n");
      out.write("    }\n");
      out.write("    tbody tr:hover{\n");
      out.write("    background : orange;\n");
      out.write("    }\n");
      out.write("  \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    </style>\n");
      out.write("\n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body>\n");
      out.write("<div id=\"content\">\n");
      out.write("<h1>\n");
      out.write("Interface Professeur\n");
      out.write("</h1>\n");
      out.write("\n");
      out.write("<button id=\"start\">Nouvelle Question</button>\n");
      out.write("<button id=\"stop\">Fin de la Question</button>\n");
      out.write("<button id=\"creer\">Nouveau cours</button><br/>\n");
      out.write("\n");
      out.write("<div id=\"cours_cache\">\n");
      out.write("<label>Intitulé</label><input type=\"text\" name=\"intitule\" id=\"intitule\"/><br/>\n");
      out.write("<label>Module</label><input type=\"text\" name=\"module\" id=\"module\"/><br/>\n");
      out.write("<button id=\"creer_cours\">Créer un cours</button>\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("\n");
      out.write("<h1>\n");
      out.write("Résultats question numéro \n");
      out.write("</h1>\n");
      out.write("\n");
      out.write("<div id=\"return\">\n");
      out.write("<table>\n");
      out.write("<thead>\n");
      out.write("<tr><th>Choix</th><th>Nombre de réponses</th></tr>\n");
      out.write("</thead>\n");
      out.write("<tbody>\n");
      out.write("<tr>\n");
      out.write("<td>A</td>\n");
      out.write("<td id=\"A\"></td>\n");
      out.write("</tr>\n");
      out.write("<tr>\n");
      out.write("<td>B</td>\n");
      out.write("<td id=\"B\"></td>\n");
      out.write("</tr>\n");
      out.write("<tr>\n");
      out.write("<td>C</td>\n");
      out.write("<td id=\"C\"></td>\n");
      out.write("</tr>\n");
      out.write("<tr>\n");
      out.write("<td>D</td>\n");
      out.write("<td id=\"D\"></td>\n");
      out.write("</tr>\n");
      out.write("</tbody>\n");
      out.write("\n");
      out.write("\n");
      out.write("</table>\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("<div id =\"chart_div\">\n");
      out.write("</div>\n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
