package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ConnexionServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)						
											throws IOException, ServletException{
		
		//On récupère login password statut de l'utilisateur		
		String login = (String)request.getParameter("login");
		String password = (String)request.getParameter("password");
		String statut= (String)request.getParameter("statut");

		//On récupère un objet session vide
		HttpSession session = request.getSession();
		
		
		//On remplit l'objet
		session.setAttribute("login", login);
		session.setAttribute("password", password);
		session.setAttribute("statut", statut);
	
		//On affiche le numéro		
		System.out.println(session.getId());

		//Pour affichage		
		request.setAttribute("id", session.getId());
		request.setAttribute("statut", statut);

		
		//La gestion du cookie
		if(request.getParameter("auto_connect") != null){
			System.out.println("Création des cookies.");
			Cookie loginCookie = new Cookie("login", login);
			Cookie passwordCookie = new Cookie("password", password);
			response.addCookie(loginCookie);
			response.addCookie(passwordCookie);
		}
	
		
		if (statut.equals("professeur"))
			request.getRequestDispatcher("admin.jsp").forward(request, response);
		else 
			request.getRequestDispatcher("remote.jsp").forward(request, response);
		
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)						
											throws IOException, ServletException{
		doGet(request, response);
	}	
}
