package com.model;

public class Entry {

	public Entry(String id, String answer) {
		this.sessionId=id;
		this.answer=answer;
			}
	public String sessionId;
	public String answer;
	
	
}
