package com.model;

import java.util.Random;

public class Cours {
	/*CREATE TABLE "Cours" ("id" INTEGER PRIMARY KEY  AUTOINCREMENT  
			NOT NULL  UNIQUE , "id_prof" INTEGER NOT NULL , "intitule"
VARCHAR, "module" VARCHAR, "login" VARCHAR);*/
	
	
	public int id;
	public int id_prof;
	public String intitule;
	public String module;
	public String login;
	
	public Cours(Professeur p,String _intitule,String _module)
	{
		this.id = 0;
		this.id_prof = p.getId();
		intitule = _intitule;
		module = _module;
		Random generator = new Random();
		login = new String( generator.nextInt()+"");
	}
	
	
	public Cours(Professeur p,String _intitule,String _module,String _login,int id)
	{
		this.id = id;
		this.id_prof = p.getId();
		intitule = _intitule;
		module = _module;
		Random generator = new Random();
		login = _login;
	}
	
	
	

}
