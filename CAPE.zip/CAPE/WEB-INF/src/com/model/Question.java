package com.model;

public class Question {
	public int A = 0;
	public int B = 0;
	public int C = 0;
	public int D = 0;
	public int numero =0;
  public int cours = 0;

	Question (int a, int b, int c, int d)
	{
		A=a;
		B=b;
		C=c;
		D=d;
	}


	Question (int numero, int cours,int a, int b, int c, int d)
	{
    this(a,b,c,d);
    this.setCours(cours);
    this.setNumero(numero);
  }
  
  String toString()
  {
    return  "{\"A\":"+a+",\"B\":"+b+",\"C\":"+c+",\"D\":"+d+"}";
  
  }


}
