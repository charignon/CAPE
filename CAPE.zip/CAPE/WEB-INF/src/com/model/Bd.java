package com.model;
import java.beans.Statement;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Bd {

	Connection conn = null;
	 
	static Bd bd = null;
	
	 private Bd(){ 
		System.out.println("Loading database driver");
	    try {Class.forName("org.sqlite.JDBC");} 
	    catch (ClassNotFoundException e) {e.printStackTrace();}
	    try {
			this.conn = DriverManager.getConnection("jdbc:sqlite:/cal/nfs3/promo12/charigno/main_db.sqlite");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	}
	
	synchronized public static Bd getObject(){
		if (bd == null)
		 Bd.bd = new Bd();
		return Bd.bd;
	}
	
	
	synchronized public void finalize()
     {
			try {
				this.conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
     }
	 
	 synchronized public void update()
	 {
		 try {
			 this.conn.close();
			 this.conn = DriverManager.getConnection("jdbc:sqlite:/cal/nfs3/promo12/charigno/main_db.sqlite");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		 
	 }
	
	 synchronized public boolean isProf(String login, String password) 
	{
  	if (getProf(login,password) == null)
		return false;
	return true;
	}

	 synchronized public boolean isUser(String login, String password) {
		if (isProf(login, password) == true || isEleve(login, password) == true){
			return true;
		}
		else {
			return false;
		}
	}

	 synchronized private boolean isEleve(String login, String password) {
		 PreparedStatement prep = null;
		    ResultSet rs = null;
			try {
				prep = conn.prepareStatement("select * from cours where login=?;");
				prep.setString(1,login);
				rs = prep.executeQuery();
				System.out.println("Recherche de l'élève : "+login);
				while (rs.next()) {
					System.out.println("UTILISATEUR CORRECT !");
				    rs.close();
					   
				      return true;
				    }
				System.out.println("UTILISATEUR INCORRECT !");
				rs.close();
			
			}		
			 catch (SQLException e) {
				e.printStackTrace();
			}
			
		
		return false;
	}
	
	 synchronized public void addCours(Cours cours)
	{
		
		PreparedStatement prep = null;
		try {
			
			
		
			
			prep = conn.prepareStatement("insert into Cours (id_prof,intitule,module,login) values (?,?,?,?);");
			prep.setInt(1,cours.id_prof);
			prep.setString(2,cours.intitule);
			prep.setString(3,cours.module );
			prep.setString(4,cours.login );
		   
		
			prep.executeUpdate();
			this.update();
			   System.out.println("Ajout d'un cours ");
		 
	
		
		
		}		
		 catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		return;
		
		
	}
	
	 synchronized public Professeur getProf(String login, String password)
	{

	    PreparedStatement prep = null;
	    ResultSet rs = null;
		try {
			prep = conn.prepareStatement("select * from professeur where login=? AND password=?;");
			prep.setString(1,login);
			prep.setString(2,password );
			rs = prep.executeQuery();
			
			while (rs.next()) {
				System.out.println("PROF!!");
				Professeur p = new Professeur();
				p.id= rs.getInt("id");
				p.nom=rs.getString("nom");
				p.prenom=rs.getString("prenom");
				p.typedeprof=rs.getString("typedeprof");
				p.login=login;
				p.password=password;
				return p;
				
				
				
			    }
			System.out.println("UTILISATEUR INCORRECT !");
			rs.close();
		
		}		
		 catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
		
		
		
	}
	
	
	
	

}
