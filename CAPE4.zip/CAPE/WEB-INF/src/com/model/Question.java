package com.model;

public class Question {
	public int A = 0;
	public int B = 0;
	public int C = 0;
	public int D = 0;
	private int numero =0;
  private int cours = 0;

	Question (int a, int b, int c, int d)
	{
		A=a;
		B=b;
		C=c;
		D=d;
	}


	Question (int numero, int cours,int a, int b, int c, int d)
	{
    this(a,b,c,d);
    this.setCours(cours);
    this.setNumero(numero);
  }
  
  public Question(int numero, int a, int b, int c, int d) {
	this(a,b,c,d);
	this.setNumero(numero);
	}


public String toString()
  {
    return  "{\"A\":"+A+",\"B\":"+B+",\"C\":"+C+",\"D\":"+D+"}";
  
  }


public void setNumero(int numero) {
	this.numero = numero;
}


public int getNumero() {
	return numero;
}


public void setCours(int cours) {
	this.cours = cours;
}


public int getCours() {
	return cours;
}


public String toCSV() {
	// TODO Auto-generated method stub
	return this.numero+","+this.A+","+this.B+","+this.C+","+this.D;
}


}
