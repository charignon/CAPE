package com.model;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

public class export {
	
	
	
	void QuestionsToCsv(ArrayList <Question> a,String filename) throws FileNotFoundException
	{
		
		PrintStream out = new PrintStream( new FileOutputStream(filename));
		out.println("SALUT");
		out.close();
		
		
		
	}
	
	
	
	

}
