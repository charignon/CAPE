package com.model;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Exporteur {

	public static void QuestionsToCsv(ArrayList<Question> questions) throws IOException {
		
		OutputStream os = new FileOutputStream("/home/laurent/FILE.csv"); 
		PrintWriter out = new PrintWriter(os);
		System.out.println("création du fichier");
		out.println("numéro,A,B,C,D");
		for (Question q : questions)
		{
			out.println(q.toCSV());
			
		}
		 out.close();
		
	}

}
