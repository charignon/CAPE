package com.model;

public class Eleve {
	Cours cours;
	Eleve (Cours cours)
	{
		this.cours = cours;
		
	}
	

}
