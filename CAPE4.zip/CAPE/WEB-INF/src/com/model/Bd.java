package com.model;
import java.beans.Statement;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Bd {

	Connection conn = null;
	ArrayList <Professeur> profs;
	ArrayList <Eleve> eleves;
	 
	static Bd bd = null;
	
	 private Bd(){ 
		 profs = new ArrayList<Professeur>();
		 eleves = new ArrayList<Eleve>();
		System.out.println("Loading database driver");
	    try {Class.forName("org.sqlite.JDBC");} 
	    catch (ClassNotFoundException e) {e.printStackTrace();}
	    try {
			this.conn = DriverManager.getConnection("jdbc:sqlite:/home/laurent/CAPE.sqlite");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	}
	
	synchronized public static Bd getObject(){
		if (bd == null)
		 Bd.bd = new Bd();
		return Bd.bd;
	}
	
	
	synchronized public void finalize()
     {
			try {
				this.conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
     }
	 
	 synchronized public void update()
	 {
		 try {
			 this.conn.close();
			 this.conn = DriverManager.getConnection("jdbc:sqlite:/home/laurent/CAPE.sqlite");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		 
	 }
	
	 synchronized public boolean isProf(String login, String password) 
	{
  	if (getProf(login,password) == null)
		return false;
	return true;
	}

	 synchronized public boolean isUser(String login, String password) {
		if (isProf(login, password) == true || isEleve(login, password) == true){
			return true;
		}
		else {
			return false;
		}
	}

	 synchronized private boolean isEleve(String login, String password) {
		 PreparedStatement prep = null;
		    ResultSet rs = null;
			try {
				prep = conn.prepareStatement("select * from cours where login=?;");
				prep.setString(1,login);
				rs = prep.executeQuery();
				System.out.println("Recherche de l'élève : "+login);
				while (rs.next()) {
					//System.out.println("UTILISATEUR CORRECT !");
				    rs.close();
					   
				      return true;
				    }
				//System.out.println("UTILISATEUR INCORRECT !");
				rs.close();
			
			}		
			 catch (SQLException e) {
				e.printStackTrace();
			}
			
		
		return false;
	}
	
	 synchronized public void addCours(Cours cours)
	{
		
		PreparedStatement prep = null;
		try {
			prep = conn.prepareStatement("insert into Cours (id_prof,intitule,module,login) values (?,?,?,?);");
			prep.setInt(1,cours.id_prof);
			prep.setString(2,cours.intitule);
			prep.setString(3,cours.module );
			prep.setString(4,cours.login );
			prep.executeUpdate();
			this.update();
			   System.out.println("Ajout d'un cours ");
		}		
		 catch (SQLException e) {
			e.printStackTrace();
		}
	return;
		
		
	}
	 synchronized public void addQuestion(Question q)
		{
			
			PreparedStatement prep = null;
			try {
				prep = conn.prepareStatement("insert into Question (num_question,id_cours,A,B,C,D) values (?,?,?,?,?,?);");
				prep.setInt(1,q.getNumero());
				prep.setInt(2,q.getCours());
				prep.setInt(3,q.A);
				prep.setInt(4,q.B);
				prep.setInt(5,q.C);
				prep.setInt(6,q.D);
				prep.executeUpdate();
				this.update();
				   System.out.println("Ajout d'une question ");
			}		
			 catch (SQLException e) {
				e.printStackTrace();
			}
		return;
			
			
		}
	
	 synchronized public Professeur getProf(String login, String password)
	{
		 //Système pour mettre un prof en cache.
		 for (Professeur p : profs)
		 {
			 if (p.login.equals(login) && p.password.equals(password))
			 {
				 
				 return p;
			 }
		}
		
		 
		 
	    PreparedStatement prep = null;
	    ResultSet rs = null;
	    
		try {
			prep = conn.prepareStatement("select * from professeur where login=? AND password=?;");
			prep.setString(1,login);
			prep.setString(2,password );
			rs = prep.executeQuery();
			//System.out.println("DEBUG !!!");
			while (rs.next()) {
				//System.out.println("PROF!!");
				Professeur p = new Professeur();
				p.id= rs.getInt("id");
				p.nom=rs.getString("nom");
				p.prenom=rs.getString("prenom");
				p.typedeprof=rs.getString("typedeprof");
				p.login=login;
				p.password=password;
				profs.add(p);
				return p;
				
				
				
			    }
			//System.out.println("UTILISATEUR INCORRECT !");
			rs.close();
		
		}		
		 catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
		
		
		
	}

	public ArrayList<Cours> getCours(String login,String password) {
		 PreparedStatement prep = null;
		 ArrayList <Cours> liste_cours = new ArrayList<Cours>();		    
		 ResultSet rs = null;
			try {
				prep = conn.prepareStatement("select * from cours where id_prof=?;");
				prep.setLong(1,this.getProf(login,password).id);
				
				rs = prep.executeQuery();
				while (rs.next()) {
					liste_cours.add(new Cours(rs.getInt("id"),
							rs.getString("intitule"),
							rs.getString("module"),
							rs.getString("login")					
						));
					
					
				    }
				rs.close();
			
				
			}		
			 catch (SQLException e) {
				e.printStackTrace();
			}
			
				return liste_cours;
					
		
		
	}

	
	public ArrayList<Question> getQuestions(String id) {
		 PreparedStatement prep = null;
		 ArrayList <Question> liste_questions = new ArrayList<Question>();		    
		 ResultSet rs = null;
			try {
				prep = conn.prepareStatement("select * from question where id_cours=?;");
				prep.setInt(1,Integer.parseInt(id));
				
				rs = prep.executeQuery();
				while (rs.next()) {
					liste_questions.add(new Question(
							rs.getInt("num_question"),
							rs.getInt("A"),
							rs.getInt("B"),
							rs.getInt("C"),
							rs.getInt("D")
							
										
						));
					
					
				    }
				rs.close();
			
				
			}		
			 catch (SQLException e) {
				e.printStackTrace();
			}
			
				return liste_questions;
	}
	
	
	
	

}
