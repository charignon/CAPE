package com.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.model.ModAcquire;

public class Listener implements ServletContextListener{

	public void contextDestroyed(ServletContextEvent event) {}

	public void contextInitialized(ServletContextEvent event) {
		event.getServletContext().setAttribute("Acquire", new ModAcquire());
	}
}
