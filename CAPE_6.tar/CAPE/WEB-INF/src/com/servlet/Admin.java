package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.ModAcquire;


public class Admin extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException{
		
		RequestDispatcher dispatch = request.getRequestDispatcher("admin.jsp");
		dispatch.forward(request, response);

	}	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException, ServletException{
	
	ModAcquire m = (ModAcquire) this.getServletContext().getAttribute("Acquire");
	String command = request.getParameter("value");
	if (command.equals("start"))
		m.start();
	if(command.equals("stop"))
		m.stop();
	if(command.equals("get"))
	{
		PrintWriter out = response.getWriter();
		out.print(m.toString());
	}
		
}	
	
	
}
