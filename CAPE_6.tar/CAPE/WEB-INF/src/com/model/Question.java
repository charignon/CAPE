package com.model;

public class Question {
	public int A = 0;
	public int B = 0;
	public int C = 0;
	public int D = 0;
	
	Question (int a, int b, int c, int d)
	{
		A=a;
		B=b;
		C=c;
		D=d;
		
	}

}
