package com.model;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

public class ModAcquire {

	ArrayList <Entry> entries;
	boolean enable;
	
	
	public ModAcquire()
	{
		this.entries = new ArrayList <Entry> ();
		this.enable = false;
	}
	
	
	
	public boolean handleResponde(HttpServletRequest request) {
		
		if (enable == true)
		{
			String id = request.getParameter("session");
			String answer = request.getParameter("value");
			System.out.println("Réception d'un réponse [" +id+","+answer+"]");
			if (hasAnswered(id))
				return false;
			else
				entries.add(new Entry(id,answer));
			return true;
		}
		else
			return false;
		}
	
	public boolean hasAnswered (String sessionId)
	{
		for (Entry p : entries)
			if (p.sessionId.equals(sessionId))
				return true;
		return false;
		
	}
	
	public void stop()
	{
		this.enable = false;
		this.flush();
	}
	public void flush()
	{
		this.entries.clear();
		
	}
	
	public void start()
	{
		this.enable=true;
	}
	
	public String toString()
	{
		int a = 0, b = 0, c = 0 , d = 0;
		for (Entry p : entries)
		{
			if(p.answer.equals("A"))
				a++;
			if(p.answer.equals("B"))
				b++;
			if(p.answer.equals("C"))
				c++;
			if(p.answer.equals("D"))
				d++;
			
			
		}
		return "{\"A\":"+a+", \"B\":"+b+", \"C\":"+c+", \"D\":"+d+"}";
				
		
		
	}
	
	
	

	
	
	
	
	
}
